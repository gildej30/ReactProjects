import React, { Component } from 'react';

class HelloWorldComponent extends Component {
    render() {
        return( 
            <div>
                HELLO WORLD! 
            </div>
        );
    }
}

export default HelloWorldComponent;