import React from 'react';
import './App.css';

import HelloWorldComponent from './components/HelloWorldComponent';

function App() {
  return (
    <h1 className="App">
      <HelloWorldComponent/>
    </h1>
  );
}

export default App;
